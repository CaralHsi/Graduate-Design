function Phi1=Phi1(x)
Phi1=3^0.5*(2*x-1);