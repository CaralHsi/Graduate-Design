function Phi2=Phi2(x)
Phi2=6*5^0.5*(x.^2-x+1/6);